<?php

return array(
	'ad-space'    => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'event'       => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'event-with-map' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'faq'         => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'job-offer'   => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'member'      => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'partner'     => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'portfolio-item'   => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'price-table' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'service-box' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'testimonial' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'toggle'      => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'product-item' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => false),
	),
	'match' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => false),
	),
	'item' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => false),
	),
	'rating' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => false),
	),
	'facility' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'infopanel' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'tour' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
	'obituary' => array(
		'package' => array('business' => true, 'developer' => true, 'themeforest' => true),
	),
);
